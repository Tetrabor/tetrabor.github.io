require.config({
    urlArgs: 't=638936165348524164'
});